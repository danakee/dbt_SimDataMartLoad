  {{ config(
    materialized='table',
    database='SimulationsAnalytics',
    alias='StageProject',
    tags=['staging'],
  )}}

WITH ProjectManager AS (
    SELECT 
         pmx.fk_Project AS ProjectPKey
        ,m.PKey         AS ProjectManagerPKey
        ,m.Employee_No  AS ProjectManagerEmployeeNumber
        ,m.First_Name   AS ProjectManagerFirstName
        ,m.Last_Name    AS ProjectManagerLastName
        ,COUNT(1) OVER (PARTITION BY pmx.fk_Project) AS MultiMgrCount
        ,ROW_NUMBER() OVER (PARTITION BY pmx.fk_Project ORDER BY m.PKey DESC) AS SeqNumber
        ,(SELECT MAX([ct]) FROM (VALUES 
            ([pmx].[hvr_change_time]), 
            ([m].[hvr_change_time])
        ) AS ChangeTime([ct])) AS [hvr_change_time]
    FROM 
        {{ source('project2', 'tblProjPMXref') }} AS pmx
        LEFT OUTER JOIN {{ source('employee2', 'tblEmployee') }} AS m
            ON pmx.fk_ProjMgr = m.PKey
    WHERE 
        pmx.CurrentPM = 1
),

ProjectData AS (
    SELECT 
         COUNT(1) OVER (PARTITION BY p.PKey) AS ProjectMultiCount
        ,p.PKey         AS ProjectPKey
        ,p.ProjName     AS ProjectName
        ,p.ProjDesc     AS ProjectDescription
        ,s.status       AS ProjectStatusCode
        ,s.Description  AS ProjectStatusDescription
        ,t.Name         AS ProjectTypeCode
        ,t.Description  AS ProjectTypeDescription
        ,a.description  AS ReportTypeDescription
        ,p.eac          AS IsEAC
        ,p.stopdr       AS IsStopDR
        ,pm.ProjectManagerFirstName
        ,pm.ProjectManagerLastName
        ,p.EffStartDt   AS EffectiveDate
        ,CAST(NULL AS bit) AS IsLatest
        ,p.CreateDt     AS ProjectCreateDate
        ,p.lastmoddt    AS ProjectUpdateDate
        ,p.ver          AS ProjectVersion
        ,(SELECT MAX([ct]) FROM (VALUES 
                ([p].[hvr_change_time]), 
                ([s].[hvr_change_time]),
                ([t].[hvr_change_time]),
                ([a].[hvr_change_time]),
                ([pm].[hvr_change_time])
        ) AS ChangeTime([ct])) AS [HvrChangeTime]        
    FROM 
        {{ source('project2', 'tblProject') }} AS p
        INNER JOIN {{ source('project2', 'tblStatus') }} AS s 
            ON p.fk_Status = s.PKey
        LEFT OUTER JOIN {{ source('project2', 'tblProjType') }} AS t 
            ON p.fk_type = t.PKey
        LEFT OUTER JOIN {{ source('project2', 'tblAccountingType') }} AS a 
            ON p.fk_reporttype = a.PKey
        LEFT OUTER JOIN ProjectManager AS pm
            ON p.PKey = pm.ProjectPKey
            AND pm.SeqNumber = 1
)

SELECT 
    *
FROM 
    ProjectData